import React from 'react'
import './css/Header.css'
function HeaderComponent() {
    return (
        <div className='header'>HeaderComponent</div>
    )
}

export default HeaderComponent